/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.demo.googlenewsapi;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONException;
import org.json.JSONObject;

public class GoogleNewsApi {

    public static void main(String[] args) throws IOException, JSONException {
        String apiKey = "1b7a6510ffb24be992a52a3dccd3f589";                       //put google news api key here
        String[] keywords = new String[]{"Dengue", "Malaria", "Covid-19"};

        Scanner scanner = new Scanner(System.in);
        System.out.println("From date (Date Format: YYYY-MM-DD)");
        String fromDate = scanner.nextLine();

        for (int i = 0; i < keywords.length; i++) {
            String keyword = keywords[i];
            String jsonString = getGoogleNewsBasedOnKeywords(apiKey, keyword, fromDate);
            JSONObject jsonObject = new JSONObject(jsonString);
            System.out.println(keyword + " articles: " + jsonObject);
        }

        scanner.close();
    }

    public static String getGoogleNewsBasedOnKeywords(String apiKey, String keyword, String fromDate)
            throws IOException {

        HttpURLConnection connection = (HttpURLConnection) new URL("https://newsapi.org/v2/everything?q=" + keyword
                + "&from=" + fromDate + "&sortBy=publishedAt&apiKey=" + apiKey).openConnection();

        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();

        if (responseCode == 200) {
            String response = "";
            Scanner scanner = new Scanner(connection.getInputStream());

            while (scanner.hasNextLine()) {
                response += scanner.nextLine();
                response += "\n";
            }
            scanner.close();
            return response;
        }
        return null;
    }
}
